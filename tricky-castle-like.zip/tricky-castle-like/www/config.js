// عدّل هذا الرابط ليطابق مستودعك على GitHub Pages (يجب أن ينتهي بـ /)
window.UPDATE_URL = "https://USERNAME.github.io/tricky-castle-like/";
