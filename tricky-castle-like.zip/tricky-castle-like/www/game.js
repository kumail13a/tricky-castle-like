(() => {
// Legend: # wall | F fake floor | ^ spike | H hidden spike | C falling stone | W saw | X fake door | K key | D door | P start
const Wd = 640, Ht = 384, T = 32, W = "####################", E = "#..................#";
const mk = (a, b, c, d) => [W, E, E, E, E, E, E, E, a, b, c, d];
const LEVELS = [
  mk("#.......K..........#", "#......###.........#", "#P...^....^^....D..#", W),
  mk("#.............K....#", "#P........H...H..D.#", "#####FFF######FF####", "#####^^^######^^####"),
  mk(E, "#P..#..W....K..D...#", W, W),
  mk("#....C.....C.......#", "#P.........K....D..#", W, W),
  mk("#.......K..........#", "#P....H...H..X..D..#", W, W),
  mk("#..............C...#", "#P.#...W...H..K...D#", "#####FFF######FFF###", "#####^^^######^^^###")
];
const HINTS = ["Grab the key, reach the door", "Not every floor is real", "Mind the saw", "Don't stand under the stones", "Which door is real?", "Everything at once"];
const cv = document.getElementById('c'), g = cv.getContext('2d');
const old = document.getElementById('pad'); if (old) old.remove();
const rnd = (a, b) => a + Math.random() * (b - a), cl = (v, a, b) => Math.max(a, Math.min(b, v));
const hash = (x, y) => ((x * 73856093) ^ (y * 19349663)) >>> 0;
const ls = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };
const touch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
const o = Object.assign({ mv: .6, sv: .8, vib: 1, shk: 1, fx: 2, pad: touch ? 1 : 0, ps: 1, lh: 0 }, ls.get('tc_opt', {}));
const sv = Object.assign({ lv: 0, d: 0, u: 0 }, ls.get('tc', {}));
const saveO = () => ls.set('tc_opt', o), persist = () => { sv.lv = lv; ls.set('tc', sv); };

// ---------- audio ----------
let ac, mg, sg, nb; const mus = { s: 0, n: 0, id: 0 };
const fq = n => 440 * 2 ** ((n - 69) / 12), SP = 60 / 104 / 2;
const CH = [[45, [57, 60, 64, 60]], [41, [53, 57, 60, 57]], [48, [55, 60, 64, 60]], [43, [55, 59, 62, 59]]];
const ML = [[76,0,72,0,74,0,72,71],[69,0,0,72,0,0,76,0],[79,0,76,0,72,0,74,0],[71,0,74,0,0,0,69,0],
            [76,0,79,0,81,0,79,76],[77,0,0,81,0,0,79,77],[76,0,72,0,67,0,72,0],[74,0,71,0,0,0,0,0]];
function vols() { if (ac) { mg.gain.value = o.mv * .5; sg.gain.value = o.sv; } }
function audio() {
  if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
  try {
    ac = new (window.AudioContext || window.webkitAudioContext)(); mg = ac.createGain(); sg = ac.createGain();
    mg.connect(ac.destination); sg.connect(ac.destination); vols();
    nb = ac.createBuffer(1, Math.floor(ac.sampleRate * .05), ac.sampleRate);
    const d = nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    mus.n = ac.currentTime + .15;
    mus.id = setInterval(() => {
      if (ac.state !== 'running') return; if (mus.n < ac.currentTime) mus.n = ac.currentTime + .05;
      while (mus.n < ac.currentTime + .3) { mstep(mus.s++, mus.n); mus.n += SP; }
    }, 60);
  } catch (e) {}
}
function tone(f, t, d, type, v, dest, f2) {
  const os = ac.createOscillator(), a = ac.createGain(); os.type = type; os.frequency.setValueAtTime(f, t);
  if (f2) os.frequency.exponentialRampToValueAtTime(f2, t + d);
  a.gain.setValueAtTime(v, t); a.gain.exponentialRampToValueAtTime(.0001, t + d);
  os.connect(a); a.connect(dest); os.start(t); os.stop(t + d + .02);
}
function mstep(s, t) {
  const bar = (s >> 3) % 8, i = s & 7, ch = CH[bar % 4];
  if (i === 0 || i === 4) tone(fq(ch[0]), t, SP * 3.5, 'triangle', .5, mg);
  tone(fq(ch[1][i & 3]), t, SP * 1.6, 'square', .07, mg);
  const m = ML[bar][i]; if (m) tone(fq(m), t, SP * 2.2, 'sine', .22, mg);
  if (i % 4 === 0) tone(110, t, .12, 'sine', .5, mg, 40);
  if (i & 1) { const sr = ac.createBufferSource(), a = ac.createGain(); sr.buffer = nb; a.gain.value = .05; sr.connect(a); a.connect(mg); sr.start(t); }
}
function snd(f, d = .1, type = 'square', v = .12, f2) { if (ac && o.sv > 0) tone(f, ac.currentTime, d, type, v, sg, f2); }

// ---------- input ----------
const K = {}, press = {}, inp = { l: 0, r: 0, j: 0 };
addEventListener('keydown', e => { audio(); if (!K[e.code]) press[e.code] = 1; K[e.code] = 1; if (/^(Arrow|Space)/.test(e.code)) e.preventDefault(); });
addEventListener('keyup', e => K[e.code] = 0);
const L = () => K.ArrowLeft || K.KeyA || inp.l, R = () => K.ArrowRight || K.KeyD || inp.r, J = () => K.ArrowUp || K.KeyW || K.Space || inp.j;
const tp = document.createElement('div'); document.body.appendChild(tp);
function buildPad() {
  tp.innerHTML = ''; const s = [.8, 1, 1.25][o.ps], z = Math.round(68 * s);
  tp.style.cssText = 'position:fixed;left:0;right:0;bottom:0;display:none;justify-content:space-between;align-items:flex-end;pointer-events:none;z-index:9;box-sizing:border-box;padding:10px 16px calc(10px + env(safe-area-inset-bottom,0px));' + (o.lh ? 'flex-direction:row-reverse' : '');
  const mkb = (txt, key) => {
    const b = document.createElement('div'); b.textContent = txt;
    b.style.cssText = `width:${z}px;height:${z}px;margin:0 6px;border-radius:50%;background:rgba(255,255,255,.16);border:2px solid rgba(255,255,255,.35);color:#fff;font:${Math.round(z*.42)}px sans-serif;display:flex;align-items:center;justify-content:center;pointer-events:auto;touch-action:none;user-select:none;-webkit-user-select:none`;
    const on = e => { e.preventDefault(); inp[key] = 1; b.style.background = 'rgba(160,140,255,.45)'; }, off = e => { inp[key] = 0; b.style.background = 'rgba(255,255,255,.16)'; };
    b.addEventListener('pointerdown', on); ['pointerup', 'pointercancel', 'pointerleave'].forEach(n => b.addEventListener(n, off));
    b.addEventListener('contextmenu', e => e.preventDefault()); return b;
  };
  const a = document.createElement('div'); a.style.display = 'flex'; a.append(mkb('◀', 'l'), mkb('▶', 'r'));
  const b = document.createElement('div'); b.append(mkb('▲', 'j')); tp.append(a, b);
}

// ---------- state ----------
let lv = Math.min(sv.lv, LEVELS.length - 1), scene = 'main', menu = null, trans = null, tick = 0, shake = 0, parts = [], hint = 0, drag = -1, padOn = false;
let map, p, has, fall, saws, blocks, hs, jp = 0, bgc, vig, resetArm = 0;
const TORCH = [[216, 150], [424, 150]];

// ---------- menus ----------
const rows = (n, y0, h, gap, w = 300) => Array.from({ length: n }, (_, i) => ({ x: (Wd - w) / 2, y: y0 + i * (h + gap), w, h }));
const go = fn => { if (!trans) trans = { a: 0, ph: 0, cb: fn }; };
function setMenu(title, items, rects, back) { menu = { title, items, rects, back, sel: Math.max(0, items.findIndex(i => !i.dis)) }; }
function startGame(i) { go(() => { lv = i; scene = 'play'; menu = null; load(); }); }
function toMain() {
  scene = 'main'; const started = sv.lv > 0 || sv.d > 0, it = [];
  it.push({ t: 'btn', l: started ? 'Continue' : 'Play', a: () => startGame(lv) });
  if (started) it.push({ t: 'btn', l: 'New Game', a: () => { lv = 0; sv.d = 0; persist(); startGame(0); } });
  it.push({ t: 'btn', l: 'Levels', a: toLevels }, { t: 'btn', l: 'Options', a: () => toOptions(toMain) }, { t: 'btn', l: 'Credits', a: toCredits });
  setMenu('', it, rows(it.length, 150, 34, 8, 260));
}
function toLevels() {
  scene = 'levels'; const it = LEVELS.map((_, i) => ({ t: 'lvl', i, dis: i > sv.u, a: () => startGame(i) }));
  it.push({ t: 'btn', l: 'Back', a: toMain });
  const r = LEVELS.map((_, i) => ({ x: 139 + (i % 3) * 126, y: 120 + Math.floor(i / 3) * 86, w: 110, h: 70 })); r.push({ x: 250, y: 310, w: 140, h: 36 });
  setMenu('Levels', it, r, toMain);
}
function toCredits() {
  scene = 'credits'; setMenu('Credits', [{ t: 'btn', l: 'Back', a: toMain }], [{ x: 250, y: 320, w: 140, h: 36 }], toMain);
}
function toOptions(back) {
  scene = 'options'; resetArm = 0;
  const sl = (l, k, f) => ({ t: 'sld', l, g: () => o[k], s: v => { o[k] = v; vols(); saveO(); f && f(); } });
  const tg = (l, k, f) => ({ t: 'tog', l, g: () => o[k], s: v => { o[k] = v ? 1 : 0; saveO(); f && f(); } });
  const it = [sl('Music', 'mv'), sl('Sound effects', 'sv', () => snd(660, .1, 'sine', .15)), tg('Vibration', 'vib'), tg('Screen shake', 'shk'),
    { t: 'cyc', l: 'Effects', n: ['Off', 'Low', 'High'], g: () => o.fx, s: v => { o.fx = v; saveO(); } },
    tg('Touch controls', 'pad'),
    { t: 'cyc', l: 'Control size', n: ['Small', 'Medium', 'Large'], g: () => o.ps, s: v => { o.ps = v; saveO(); buildPad(); } },
    tg('Left-handed', 'lh', buildPad),
    { t: 'btn', l: 'Reset progress', a: () => { if (!resetArm) { resetArm = 1; it[8].l = 'Tap again to confirm'; } else { sv.lv = 0; sv.d = 0; sv.u = 0; lv = 0; persist(); it[8].l = 'Progress reset'; resetArm = 0; } } },
    { t: 'btn', l: 'Back', a: back }];
  setMenu('Options', it, rows(10, 62, 27, 4, 380), back);
}
function pause() {
  scene = 'pause'; const it = [{ t: 'btn', l: 'Resume', a: () => { scene = 'play'; menu = null; } },
    { t: 'btn', l: 'Restart level', a: () => go(() => { scene = 'play'; menu = null; load(); }) },
    { t: 'btn', l: 'Options', a: () => toOptions(pause) }, { t: 'btn', l: 'Main menu', a: () => go(() => { toMain(); }) }];
  setMenu('Paused', it, rows(4, 130, 36, 8, 260), () => { scene = 'play'; menu = null; });
}
function toWin() {
  scene = 'win'; setMenu('', [{ t: 'btn', l: 'Play again', a: () => { sv.d = 0; lv = 0; persist(); startGame(0); } }, { t: 'btn', l: 'Main menu', a: () => go(toMain) }], rows(2, 250, 36, 8, 240));
}
function activate(i, x) {
  const it = menu.items[i], r = menu.rects[i]; if (it.dis) return; snd(520, .06, 'square', .08);
  if (it.t === 'btn' || it.t === 'lvl') it.a(); else if (it.t === 'tog') it.s(!it.g());
  else if (it.t === 'cyc') it.s((it.g() + 1) % it.n.length);
  else if (it.t === 'sld') it.s(Math.round(cl((x - (r.x + r.w - 130)) / 116, 0, 1) * 10) / 10);
}
function hitMenu(x, y) { return menu ? menu.rects.findIndex(r => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) : -1; }
function mpos(e) { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * Wd / r.width, (e.clientY - r.top) * Ht / r.height]; }
cv.addEventListener('pointerdown', e => {
  audio(); const [x, y] = mpos(e);
  if (scene === 'play') { if (x > Wd - 50 && y < 46) pause(); return; }
  const i = hitMenu(x, y); if (i >= 0) { menu.sel = i; activate(i, x); if (menu && menu.items[i] && menu.items[i].t === 'sld') drag = i; }
});
cv.addEventListener('pointermove', e => { if (drag >= 0 && menu) { const [x] = mpos(e); const it = menu.items[drag], r = menu.rects[drag]; if (it) it.s(Math.round(cl((x - (r.x + r.w - 130)) / 116, 0, 1) * 10) / 10); } });
addEventListener('pointerup', () => drag = -1);
function menuKeys() {
  if (!menu) return; const n = menu.items.length, it = menu.items[menu.sel];
  const mv = d => { let i = menu.sel; do { i = (i + d + n) % n; } while (menu.items[i].dis); menu.sel = i; snd(400, .04, 'square', .05); };
  if (press.ArrowDown || press.KeyS) mv(1); if (press.ArrowUp || press.KeyW) mv(-1);
  if (menu.items[0].t === 'lvl' && (press.ArrowRight || press.ArrowLeft)) mv(press.ArrowRight ? 1 : -1);
  if (it && (press.ArrowRight || press.ArrowLeft) && it.t !== 'lvl') { const d = press.ArrowRight ? 1 : -1;
    if (it.t === 'sld') it.s(Math.round(cl(it.g() + d * .1, 0, 1) * 10) / 10); else if (it.t === 'tog') it.s(d > 0); else if (it.t === 'cyc') it.s((it.g() + d + it.n.length) % it.n.length); }
  if (press.Enter || press.Space) activate(menu.sel, menu.rects[menu.sel].x + menu.rects[menu.sel].w - 20);
  if (press.Escape && menu.back) menu.back();
}

// ---------- game ----------
function load() {
  map = LEVELS[lv].map(r => r.split('')); has = false; fall = {}; saws = []; blocks = []; hs = []; parts = []; jp = 0;
  map.forEach((row, y) => row.forEach((c, x) => {
    if (c === 'P') { p = { x: x*T+5, y: y*T+4, w: 22, h: 28, vx: 0, vy: 0, on: false, face: 1, sx: 1, sy: 1, run: 0, coy: 0, buf: 0, dead: 0, fin: 0 }; row[x] = '.'; }
    if (c === 'W') { saws.push({ x: x*T+16, y: y*T+16, dir: 1, a: 0 }); row[x] = '.'; }
    if (c === 'C') { blocks.push({ x: x*T, y: y*T, vy: 0, st: 0 }); row[x] = '.'; }
    if (c === 'H') { hs.push({ x: x*T, y: y*T, g: 0, s: 0 }); row[x] = '.'; }
  }));
  hint = 170; sv.u = Math.max(sv.u, lv); persist();
}
const solid = c => c === '#' || c === 'F';
function hit(x, y, w, h, f) {
  for (let ty = Math.floor(y/T); ty <= Math.floor((y+h-1)/T); ty++)
    for (let tx = Math.floor(x/T); tx <= Math.floor((x+w-1)/T); tx++)
      if (f((map[ty] || [])[tx] || '#', tx, ty)) return true;
  return false;
}
const solidAt = () => hit(p.x, p.y, p.w, p.h, solid);
function spawn(x, y, n, c, s = 2, gr = .15) {
  if (!o.fx) return; n = Math.ceil(n * (o.fx === 1 ? .5 : 1));
  for (let i = 0; i < n; i++) parts.push({ x, y, vx: rnd(-s, s), vy: rnd(-s * 1.2, s * .3), l: rnd(20, 40), m: 40, c, gr, z: rnd(2, 4) });
}
function die() {
  if (p.dead) return; sv.d++; persist(); p.dead = 42; shake = 12;
  spawn(p.x + 11, p.y + 14, 26, '#5bf', 4, .25); spawn(p.x + 11, p.y + 14, 14, '#e45', 3, .25);
  if (o.vib && navigator.vibrate) { try { navigator.vibrate(60); } catch (e) {} } snd(160, .4, 'sawtooth', .14, 40);
}
function play() {
  if (press.Escape || press.KeyP) { pause(); return; }
  if (p.dead) { if (--p.dead === 0) go(load); return; }
  const px = p.x + p.w / 2, py = p.y + p.h / 2, dir = p.fin ? 0 : (R() ? 1 : 0) - (L() ? 1 : 0), dv = dir * 3.2 - p.vx;
  p.vx += Math.sign(dv) * Math.min(Math.abs(dv), dir ? (p.on ? .6 : .4) : (p.on ? .8 : .12));
  if (dir) p.face = dir;
  const jd = !p.fin && J(); if (jd && !jp) p.buf = 7; jp = jd; if (p.buf > 0) p.buf--;
  if (p.on) p.coy = 6; else if (p.coy > 0) p.coy--;
  if (p.buf > 0 && p.coy > 0) { p.vy = -10.8; p.buf = 0; p.coy = 0; p.on = false; p.sx = .78; p.sy = 1.28; snd(380, .14, 'square', .1, 760); spawn(px, p.y + p.h, 6, '#b9b3d9', 1.5, .05); }
  if (!jd && p.vy < -4) p.vy *= .72;
  p.vy = Math.min(p.vy + .58, 12.5);
  const wasOn = p.on, vy0 = p.vy;
  p.x += p.vx; if (solidAt()) { p.x -= p.vx; p.vx = 0; }
  p.y += p.vy; p.on = false;
  if (solidAt()) { const s = Math.sign(p.vy); while (solidAt()) p.y -= s; if (s > 0) p.on = true; p.vy = 0; }
  if (p.on && !wasOn && vy0 > 4) { p.sx = 1.3; p.sy = .72; snd(140, .08, 'triangle', .12); spawn(px, p.y + p.h, 8, '#b9b3d9', 1.8, .05); }
  p.sx += (1 - p.sx) * .2; p.sy += (1 - p.sy) * .2;
  if (p.on && Math.abs(p.vx) > .6) { p.run += Math.abs(p.vx) * .14; if (tick % 9 === 0) spawn(px, p.y + p.h, 1, '#8b84b5', .6, .03); } else if (p.on) p.run = 0;
  hit(p.x, p.y + p.h, p.w, 1, (c, tx, ty) => {
    if (c === 'F') { const k = tx + ',' + ty; fall[k] = (fall[k] || 0) + 1; if (fall[k] > 18) { map[ty][tx] = '.'; snd(90, .25, 'triangle', .14); spawn(tx*T+16, ty*T+16, 12, '#6b6490', 2.2, .2); shake = 5; } }
    return false;
  });
  for (const s of saws) {
    s.x += s.dir * 2; s.a += .3;
    if (solid((map[Math.floor(s.y/T)] || [])[Math.floor((s.x + s.dir*14)/T)] || '#')) s.dir *= -1;
    if (Math.hypot(s.x - px, s.y - py) < 22) die();
    if (tick % 4 === 0) spawn(s.x, s.y + 12, 1, '#fd8', 1.2, .2);
  }
  for (const b of blocks) {
    if (b.st === 0 && Math.abs(px - (b.x + 16)) < 38 && p.y > b.y) { b.st = 1; snd(220, .1, 'triangle', .12); }
    if (b.st === 1) {
      b.vy += .8; b.y += b.vy;
      if (solid((map[Math.floor((b.y + T)/T)] || [])[Math.floor((b.x + 16)/T)] || '#')) { b.st = 2; snd(70, .25, 'triangle', .18); shake = 8; spawn(b.x + 16, b.y + T, 14, '#8b84b5', 2.5, .2); }
      if (b.x < p.x + p.w && b.x + T > p.x && b.y < p.y + p.h && b.y + T > p.y) die();
    }
  }
  for (const h of hs) {
    const near = Math.abs(px - (h.x + 16)) < 75 && Math.abs(py - (h.y + 16)) < 48;
    h.g = cl(h.g + (near ? .18 : -.05), 0, 1);
    if (h.g > .1 && !h.s) { h.s = 1; snd(900, .06, 'square', .07); } if (h.g < .05) h.s = 0;
    if (h.g > .6 && h.x + 4 < p.x + p.w && h.x + 28 > p.x && h.y + T - h.g * 24 < p.y + p.h && h.y + T > p.y) die();
  }
  let next = false, dead = false;
  hit(p.x, p.y, p.w, p.h, (c, tx, ty) => {
    if (c === 'K') { map[ty][tx] = '.'; has = true; snd(880, .25, 'sine', .15, 1320); spawn(tx*T+16, ty*T+16, 14, '#fc3', 2.5, .05); }
    if (c === 'D' && has) next = true; return false;
  });
  hit(p.x + 4, p.y + 4, p.w - 8, p.h - 8, (c) => { if (c === '^' || c === 'X') dead = true; return false; });
  if (dead || p.y > Ht + 40) die();
  if (next && !p.dead && !p.fin) {
    p.fin = 1; snd(660, .35, 'sine', .15, 990); spawn(px, py, 24, '#4d6', 3.5, .1);
    go(() => { if (lv + 1 >= LEVELS.length) { sv.u = LEVELS.length - 1; lv = 0; persist(); toWin(); } else { lv++; load(); } });
  }
}
function update() {
  tick++; if (shake > 0) shake *= .86;
  if (trans) { if (trans.ph === 0) { trans.a += .09; if (trans.a >= 1) { trans.ph = 1; trans.cb(); } } else { trans.a -= .07; if (trans.a <= 0) trans = null; } }
  if (!trans || trans.ph === 1) { if (scene === 'play') play(); else menuKeys(); }
  const show = o.pad && scene === 'play'; if (show !== padOn) { padOn = show; tp.style.display = show ? 'flex' : 'none'; }
  if (scene !== 'play' && scene !== 'pause' && tick % 5 === 0 && o.fx) parts.push({ x: rnd(0, Wd), y: Ht + 4, vx: rnd(-.3, .3), vy: rnd(-1.8, -.6), l: 90, m: 90, c: '#f93', gr: -.004, z: rnd(1.5, 3) });
  for (const q of parts) { q.vy += q.gr; q.x += q.vx; q.y += q.vy; q.l--; } parts = parts.filter(q => q.l > 0);
  for (const k in press) delete press[k];
}

// ---------- drawing ----------
function rr(x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function txt(s, x, y, sz, col = '#fff', al = 'center', w = 'bold') { g.font = `${w} ${sz}px system-ui, sans-serif`; g.textAlign = al; g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.6)'; g.strokeText(s, x, y); g.fillStyle = col; g.fillText(s, x, y); }
function mkcanvas() { const c = document.createElement('canvas'); c.width = cv.width; c.height = cv.height; const x = c.getContext('2d'); x.setTransform(cv.width / Wd, 0, 0, cv.height / Ht, 0, 0); return [c, x]; }
function buildBg() {
  let x; [bgc, x] = mkcanvas(); const G = g; 
  const s = x.createLinearGradient(0, 0, 0, Ht); s.addColorStop(0, '#271f4d'); s.addColorStop(1, '#0d0a1c'); x.fillStyle = s; x.fillRect(0, 0, Wd, Ht);
  for (let ty = 0; ty < 12; ty++) for (let tx = 0; tx < 20; tx++) {
    const h = hash(tx, ty) % 4; x.fillStyle = ['#2a2350', '#272049', '#2d2654', '#252046'][h]; x.fillRect(tx*T, ty*T, T, T);
    x.fillStyle = 'rgba(0,0,0,.25)'; x.fillRect(tx*T, ty*T + 15, T, 1); x.fillRect(tx*T + (ty & 1 ? 8 : 20), ty*T, 1, 15); x.fillRect(tx*T + (ty & 1 ? 22 : 6), ty*T + 16, 1, 16);
  }
  [112, 320, 528].forEach((cx, k) => {
    const w = 64, X = cx - w / 2, Y = 40, H = 128; x.beginPath(); x.moveTo(X, Y + H); x.lineTo(X, Y + w / 2); x.arc(cx, Y + w / 2, w / 2, Math.PI, 0); x.lineTo(X + w, Y + H); x.closePath();
    const gr = x.createLinearGradient(0, Y, 0, Y + H); gr.addColorStop(0, '#3a3c8a'); gr.addColorStop(1, '#0d0b24'); x.fillStyle = gr; x.fill();
    x.save(); x.clip(); x.fillStyle = '#fff'; for (let i = 0; i < 9; i++) x.fillRect(X + (hash(i, k) % w), Y + (hash(k, i) % H), 1.5, 1.5);
    if (k === 1) { x.fillStyle = '#fbeaa8'; x.beginPath(); x.arc(cx + 8, Y + 38, 11, 0, 7); x.fill(); x.fillStyle = '#2e2f78'; x.beginPath(); x.arc(cx + 14, Y + 34, 10, 0, 7); x.fill(); } x.restore();
    x.lineWidth = 5; x.strokeStyle = '#4e4873'; x.stroke(); x.fillStyle = '#4e4873'; x.fillRect(cx - 2, Y, 4, H); x.fillRect(X, Y + 50, w, 4);
  });
  TORCH.forEach(([tx, ty]) => { x.fillStyle = '#4a3a2e'; x.fillRect(tx - 4, ty - 4, 8, 26); x.fillStyle = '#6b6490'; x.fillRect(tx - 9, ty - 8, 18, 6); });
  [vig, x] = mkcanvas(); const v = x.createRadialGradient(Wd/2, Ht/2, Ht*.35, Wd/2, Ht/2, Wd*.62); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,.6)'); x.fillStyle = v; x.fillRect(0, 0, Wd, Ht);
}
function tile(c, x, y) {
  const X = x*T, Y = y*T, h = hash(x, y) % 5;
  if (c === '#' || c === 'F') {
    g.fillStyle = ['#6b6490', '#675f8c', '#71699a', '#645c88', '#6e6794'][h]; g.fillRect(X, Y, T, T);
    g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(X, Y + 15, T, 2); g.fillRect(X + (h & 1 ? 10 : 20), Y, 2, 15); g.fillRect(X + (h & 1 ? 22 : 8), Y + 17, 2, 15);
    g.fillStyle = 'rgba(255,255,255,.16)'; g.fillRect(X, Y, T, 2); g.fillRect(X, Y, 2, T);
    const up = (map[y - 1] || [])[x]; if (up && !solid(up) && h < 3) { g.fillStyle = '#4a8a5c'; g.fillRect(X, Y, T, 3); g.fillRect(X + 4, Y + 3, 4, 2); g.fillRect(X + 18, Y + 3, 6, 2); }
  } else if (c === '^') spike(X, Y, 1);
  else if (c === 'K') { const b = Math.sin(tick / 12 + x) * 3, gl = g.createRadialGradient(X+16, Y+16+b, 2, X+16, Y+16+b, 22); gl.addColorStop(0, 'rgba(255,210,60,.5)'); gl.addColorStop(1, 'rgba(255,210,60,0)'); g.fillStyle = gl; g.fillRect(X - 8, Y - 8, 48, 48);
    g.fillStyle = '#fc3'; g.beginPath(); g.arc(X+11, Y+14+b, 6, 0, 7); g.fill(); g.fillStyle = '#271f4d'; g.beginPath(); g.arc(X+11, Y+14+b, 2.5, 0, 7); g.fill(); g.fillStyle = '#fc3'; g.fillRect(X+15, Y+12+b, 13, 4); g.fillRect(X+23, Y+16+b, 3, 6); g.fillRect(X+19, Y+16+b, 3, 4); }
  else if (c === 'D' || c === 'X') {
    if (c === 'D' && has) { const gl = g.createRadialGradient(X+16, Y+18, 2, X+16, Y+18, 34); gl.addColorStop(0, 'rgba(90,255,130,.55)'); gl.addColorStop(1, 'rgba(90,255,130,0)'); g.fillStyle = gl; g.fillRect(X - 20, Y - 16, 72, 64); }
    g.fillStyle = '#3b2b22'; g.beginPath(); g.moveTo(X+1, Y+T); g.lineTo(X+1, Y+14); g.arc(X+16, Y+14, 15, Math.PI, 0); g.lineTo(X+31, Y+T); g.fill();
    g.fillStyle = c === 'D' && has ? '#58c878' : '#a8683a'; g.beginPath(); g.moveTo(X+4, Y+T); g.lineTo(X+4, Y+14); g.arc(X+16, Y+14, 12, Math.PI, 0); g.lineTo(X+28, Y+T); g.fill();
    g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(X+10, Y+6, 2, 26); g.fillRect(X+20, Y+6, 2, 26); g.fillStyle = '#fd5'; g.beginPath(); g.arc(X+23, Y+20, 2.5, 0, 7); g.fill();
  }
}
function spike(X, Y, k) {
  for (let i = 0; i < 2; i++) { const bx = X + i * 16, top = Y + T - 24 * k; const gr = g.createLinearGradient(bx, top, bx + 16, top); gr.addColorStop(0, '#e8f0f8'); gr.addColorStop(1, '#7d8ea0');
    g.fillStyle = gr; g.beginPath(); g.moveTo(bx + 1, Y + T); g.lineTo(bx + 8, top); g.lineTo(bx + 15, Y + T); g.fill(); }
}
function knight() {
  if (p.dead) return; const cx = p.x + p.w / 2, by = p.y + p.h, sw = Math.sin(p.run) * 5, br = p.on && !p.run ? Math.sin(tick / 14) * .8 : 0;
  g.save(); g.translate(cx, by); g.scale(p.face * p.sx, p.sy);
  const air = !p.on ? cl(p.vy * .5, -4, 4) : 0, tilt = cl(p.vx, -3, 3) * 1.2;
  g.fillStyle = '#c33'; g.beginPath(); g.moveTo(-5, -20); g.lineTo(-12 - Math.abs(p.vx) * 1.5, -9 + air); g.lineTo(-10 - Math.abs(p.vx), -4 + air); g.lineTo(-2, -8); g.fill();
  g.fillStyle = '#4a4468'; g.fillRect(-7 + sw, -8, 6, 8); g.fillRect(1 - sw, -8, 6, 8);
  g.fillStyle = '#8fa0b8'; g.fillRect(-6 + sw, -3, 7, 3); g.fillRect(0 - sw, -3, 7, 3);
  g.fillStyle = '#5bf'; rr(-8, -21 + br, 16, 14, 3); g.fill(); g.fillStyle = '#3a86d8'; g.fillRect(-8, -12 + br, 16, 3);
  g.fillStyle = '#c9d3e0'; g.save(); g.translate(8, -14 + br); g.rotate(.6 + Math.sin(p.run) * .1); g.fillRect(-1, -12, 3, 14); g.fillStyle = '#a63'; g.fillRect(-3, 1, 7, 3); g.restore();
  g.fillStyle = '#b8c4d4'; rr(-8, -31 + br, 16, 12, 4); g.fill(); g.fillStyle = '#10142a'; g.fillRect(0, -27 + br, 8, 3);
  g.fillStyle = '#e44'; g.beginPath(); g.moveTo(-3, -31 + br); g.lineTo(-8 - tilt, -37 + br - Math.abs(air)); g.lineTo(3, -33 + br); g.fill();
  g.restore();
}
function drawWorld() {
  g.drawImage(bgc, 0, 0, Wd, Ht);
  if (!map) return;
  map.forEach((row, y) => row.forEach((c, x) => { if (c !== '.') tile(c, x, y); }));
  for (const h of hs) if (h.g > .02) spike(h.x, h.y, h.g);
  for (const b of blocks) if (b.st < 2) {
    const jx = b.st === 0 && p && Math.abs(p.x + 11 - b.x - 16) < 80 ? Math.sin(tick * 2) * 1.2 : 0; g.save(); g.translate(b.x + jx, b.y);
    g.fillStyle = '#5a5380'; g.fillRect(0, 0, T, T); g.fillStyle = '#7a73a6'; g.fillRect(0, 0, T, 3); g.fillStyle = '#e45'; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(i*8 + 1, T); g.lineTo(i*8 + 5, T + 6); g.lineTo(i*8 + 8, T); g.fill(); }
    g.fillStyle = '#2a2350'; g.fillRect(8, 10, 6, 4); g.fillRect(19, 10, 6, 4); g.fillRect(10, 20, 12, 3); g.restore(); }
  for (const s of saws) { g.save(); g.translate(s.x, s.y); g.rotate(s.a); g.fillStyle = '#cfe0f0'; for (let i = 0; i < 8; i++) { g.rotate(Math.PI / 4); g.beginPath(); g.moveTo(-4, -9); g.lineTo(0, -16); g.lineTo(4, -9); g.fill(); }
    g.beginPath(); g.arc(0, 0, 11, 0, 7); g.fill(); g.fillStyle = '#7d8ea0'; g.beginPath(); g.arc(0, 0, 6, 0, 7); g.fill(); g.fillStyle = '#334'; g.fillRect(-2, -2, 4, 4); g.restore(); }
  if (p) knight();
  g.globalCompositeOperation = 'lighter';
  TORCH.forEach(([tx, ty], i) => { const f = Math.sin(tick / 3 + i * 2) * 2 + Math.sin(tick / 7 + i) * 2, gl = g.createRadialGradient(tx, ty - 12, 4, tx, ty - 12, 90 + f * 3); gl.addColorStop(0, 'rgba(255,170,60,.35)'); gl.addColorStop(1, 'rgba(255,120,30,0)'); g.fillStyle = gl; g.fillRect(tx - 100, ty - 110, 200, 200); });
  g.globalCompositeOperation = 'source-over';
  TORCH.forEach(([tx, ty], i) => { const f = Math.sin(tick / 3 + i * 2) * 2; g.fillStyle = '#f93'; g.beginPath(); g.ellipse(tx, ty - 10, 6 + f / 2, 11 + f, 0, 0, 7); g.fill(); g.fillStyle = '#fd5'; g.beginPath(); g.ellipse(tx, ty - 8, 3, 6 + f / 2, 0, 0, 7); g.fill(); });
}
function drawParts() { for (const q of parts) { g.globalAlpha = cl(q.l / q.m, 0, 1); g.fillStyle = q.c; g.fillRect(q.x, q.y, q.z, q.z); } g.globalAlpha = 1; }
function drawMenu() {
  if (menu.title) txt(menu.title, Wd / 2, scene === 'options' ? 44 : 70, 30, '#fff');
  menu.items.forEach((it, i) => {
    const r = menu.rects[i], s = i === menu.sel; g.globalAlpha = it.dis ? .4 : 1;
    g.fillStyle = s ? 'rgba(130,110,235,.65)' : 'rgba(26,20,56,.78)'; rr(r.x, r.y, r.w, r.h, 8); g.fill(); g.lineWidth = 2; g.strokeStyle = s ? '#c7bdff' : 'rgba(255,255,255,.18)'; g.stroke();
    const cy = r.y + r.h / 2 + 5, fs = r.h < 30 ? 14 : 17;
    if (it.t === 'btn') txt(it.l, r.x + r.w / 2, cy, fs, '#fff');
    else if (it.t === 'lvl') { txt(String(it.i + 1), r.x + r.w / 2, r.y + 44, 34, '#fff'); if (it.dis) { g.fillStyle = '#fc3'; g.fillRect(r.x + r.w/2 - 9, r.y + 24, 18, 14); g.strokeStyle = '#fc3'; g.lineWidth = 3; g.beginPath(); g.arc(r.x + r.w/2, r.y + 24, 6, Math.PI, 0); g.stroke(); } }
    else {
      txt(it.l, r.x + 14, cy, fs, '#fff', 'left', 'normal');
      if (it.t === 'sld') { const bx = r.x + r.w - 130; g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(bx, r.y + r.h / 2 - 3, 116, 6); g.fillStyle = '#9d8cff'; g.fillRect(bx, r.y + r.h / 2 - 3, 116 * it.g(), 6); g.fillStyle = '#fff'; g.beginPath(); g.arc(bx + 116 * it.g(), r.y + r.h / 2, 8, 0, 7); g.fill(); }
      else txt(it.t === 'tog' ? (it.g() ? 'ON' : 'OFF') : it.n[it.g()], r.x + r.w - 14, cy, fs, it.t === 'tog' && it.g() ? '#7df29a' : '#e8e4ff', 'right');
    }
    g.globalAlpha = 1;
  });
}
function render() {
  g.setTransform(cv.width / Wd, 0, 0, cv.height / Ht, 0, 0); g.save();
  if (shake > .3 && o.shk) g.translate(rnd(-shake, shake) * .5, rnd(-shake, shake) * .5);
  const inGame = scene === 'play' || scene === 'pause' || scene === 'win';
  if (inGame) drawWorld(); else g.drawImage(bgc, 0, 0, Wd, Ht);
  drawParts(); g.restore(); g.drawImage(vig, 0, 0, Wd, Ht);
  if (scene === 'play') {
    txt(`Level ${lv + 1}/${LEVELS.length}`, 10, 22, 14, '#fff', 'left'); txt(`Deaths ${sv.d}`, 10, 40, 12, '#cfc8ff', 'left');
    if (has) txt('KEY', 10, 58, 12, '#fc3', 'left');
    g.fillStyle = 'rgba(0,0,0,.4)'; rr(Wd - 40, 8, 30, 30, 8); g.fill(); g.fillStyle = '#fff'; g.fillRect(Wd - 31, 15, 5, 16); g.fillRect(Wd - 22, 15, 5, 16);
    if (hint > 0) { hint--; g.globalAlpha = cl(Math.min(hint, 40) / 40, 0, 1); txt(HINTS[lv], Wd / 2, 70, 18, '#ffe9a8'); g.globalAlpha = 1; }
  }
  if (scene === 'main') { txt('Racepord castel', Wd / 2, 80, 44, '#fff'); txt('a castle full of tricks', Wd / 2, 108, 15, '#cfc8ff', 'center', 'normal'); }
  if (scene === 'pause') { g.fillStyle = 'rgba(0,0,0,.5)'; g.fillRect(0, 0, Wd, Ht); }
  if (scene === 'win') { g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(0, 0, Wd, Ht); txt('You escaped the castle!', Wd / 2, 150, 34, '#ffe9a8'); txt('Deaths: ' + sv.d, Wd / 2, 190, 18, '#fff'); }
  if (scene === 'credits') ['Racepord castel', 'HTML5 canvas puzzle-platformer', 'All art and music generated in code', 'Inspired by classic trap-castle games'].forEach((s, i) => txt(s, Wd / 2, 140 + i * 36, i ? 16 : 24, '#fff', 'center', i ? 'normal' : 'bold'));
  if (menu) drawMenu();
  if (trans) { g.fillStyle = `rgba(8,6,16,${cl(trans.a, 0, 1)})`; g.fillRect(0, 0, Wd, Ht); }
}

// ---------- boot ----------
function fit() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2), w = Math.min(innerWidth, innerHeight * Wd / Ht);
  cv.width = Math.round(w * dpr); cv.height = Math.round(w * dpr * Ht / Wd);
  cv.style.cssText = `width:${w}px;height:${w * Ht / Wd}px;max-width:none;max-height:none;aspect-ratio:auto;display:block;touch-action:none`;
  document.body.style.cssText = 'margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#0b0914;overflow:hidden;touch-action:none';
  buildBg();
}
document.addEventListener('visibilitychange', () => { if (ac) { document.hidden ? ac.suspend() : ac.resume(); } if (document.hidden && scene === 'play') pause(); });
addEventListener('resize', fit); document.addEventListener('contextmenu', e => e.preventDefault());
fit(); buildPad(); load(); toMain();
let last = performance.now(), acc = 0;
(function loop(now) { acc += Math.min(now - last, 100); last = now; while (acc >= 16.667) { update(); acc -= 16.667; } render(); requestAnimationFrame(loop); })(last);
})();
