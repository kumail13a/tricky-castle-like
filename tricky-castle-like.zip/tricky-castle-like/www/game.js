// Legend: # wall | F fake floor (collapses) | ^ spike | H hidden spike (pops up near)
// C falling block | W patrol saw | X fake door (deadly) | K key | D door | P start
const T = 32, W = "####################", E = "#..................#";
const mk = (a, b, c, d) => [W, E, E, E, E, E, E, E, a, b, c, d];
const LEVELS = [
  mk("#.......K..........#", "#......###.........#", "#P...^....^^....D..#", W),
  mk("#.............K....#", "#P........H...H..D.#", "#####FFF######FF####", "#####^^^######^^####"),
  mk(E, "#P..#..W....K..D...#", W, W),
  mk("#....C.....C.......#", "#P.........K....D..#", W, W),
  mk("#.......K..........#", "#P....H...H..X..D..#", W, W),
  mk("#..............C...#", "#P.#...W...H..K...D#", "#####FFF######FFF###", "#####^^^######^^^###")
];
const cv = document.getElementById('c'), g = cv.getContext('2d');
const K = {}; let lv = 0, deaths = 0, won = false, map, p, has, fall, saws, blocks, face = 1, ac, tick = 0;
try { const s = JSON.parse(localStorage.getItem('tc') || '{}'); lv = Math.min(s.lv || 0, LEVELS.length - 1); deaths = s.d || 0; } catch (e) {}
const save = () => { try { localStorage.setItem('tc', JSON.stringify({ lv, d: deaths })); } catch (e) {} };

function snd(f, d = .1, t = 'square', v = .05) {
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    const o = ac.createOscillator(), a = ac.createGain();
    o.type = t; o.frequency.value = f; a.gain.value = v; o.connect(a); a.connect(ac.destination);
    o.start(); a.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + d); o.stop(ac.currentTime + d);
  } catch (e) {}
}
addEventListener('keydown', e => { K[e.code] = 1; if (e.code.startsWith('Arrow') || e.code === 'Space') e.preventDefault(); });
addEventListener('keyup', e => K[e.code] = 0);
document.querySelectorAll('#pad button').forEach(b => {
  const k = b.dataset.k;
  b.addEventListener('touchstart', e => { e.preventDefault(); K[k] = 1; });
  b.addEventListener('touchend', () => K[k] = 0);
  b.addEventListener('mousedown', () => K[k] = 1);
  b.addEventListener('mouseup', () => K[k] = 0);
});

function load() {
  map = LEVELS[lv].map(r => r.split('')); has = false; fall = {}; saws = []; blocks = [];
  map.forEach((row, y) => row.forEach((c, x) => {
    if (c === 'P') { p = { x: x*T+5, y: y*T+4, w: 22, h: 28, vx: 0, vy: 0, on: false }; row[x] = '.'; }
    if (c === 'W') { saws.push({ x: x*T+16, y: y*T+16, dir: 1 }); row[x] = '.'; }
    if (c === 'C') { blocks.push({ x: x*T, y: y*T, vy: 0, st: 0 }); row[x] = '.'; }
  }));
}
const solid = c => c === '#' || c === 'F';
function hit(x, y, w, h, f) {
  for (let ty = Math.floor(y/T); ty <= Math.floor((y+h-1)/T); ty++)
    for (let tx = Math.floor(x/T); tx <= Math.floor((x+w-1)/T); tx++)
      if (f((map[ty] || [])[tx] || '#', tx, ty)) return true;
  return false;
}
const near = tx => Math.abs(p.x + p.w/2 - (tx*T + 16)) < 75;
const solidAt = () => hit(p.x, p.y, p.w, p.h, solid);
function die() { deaths++; snd(120, .35, 'sawtooth', .08); load(); save(); }

function step() {
  tick++;
  if (won) { if (K.Space || K.ArrowUp) { won = false; lv = 0; deaths = 0; save(); load(); } return; }
  const dir = (K.ArrowRight || K.KeyD ? 1 : 0) - (K.ArrowLeft || K.KeyA ? 1 : 0);
  p.vx = dir * 3; if (dir) face = dir;
  if ((K.Space || K.ArrowUp || K.KeyW) && p.on) { p.vy = -10.5; p.on = false; snd(520, .12); }
  p.vy = Math.min(p.vy + .55, 12);
  p.x += p.vx; if (solidAt()) p.x -= p.vx;
  p.y += p.vy; p.on = false;
  if (solidAt()) { const d = Math.sign(p.vy); while (solidAt()) p.y -= d; if (d > 0) p.on = true; p.vy = 0; }
  // fake floors collapse after ~0.3s
  hit(p.x, p.y + p.h, p.w, 1, (c, tx, ty) => {
    if (c === 'F') { const k = tx + ',' + ty; fall[k] = (fall[k] || 0) + 1; if (fall[k] > 18) { map[ty][tx] = '.'; snd(90, .25, 'triangle', .08); } }
    return false;
  });
  // saws patrol
  const pcx = p.x + p.w/2, pcy = p.y + p.h/2;
  for (const s of saws) {
    s.x += s.dir * 2;
    if (solid((map[Math.floor(s.y/T)] || [])[Math.floor((s.x + s.dir*14)/T)] || '#')) s.dir *= -1;
    if (Math.hypot(s.x - pcx, s.y - pcy) < 22) return die();
  }
  // falling blocks
  for (const b of blocks) {
    if (b.st === 0 && Math.abs(pcx - (b.x+16)) < 38 && p.y > b.y) { b.st = 1; snd(200, .1, 'triangle'); }
    if (b.st === 1) {
      b.vy += .8; b.y += b.vy;
      if (solid((map[Math.floor((b.y + T)/T)] || [])[Math.floor((b.x+16)/T)] || '#')) { b.st = 2; snd(70, .2, 'triangle', .08); }
      if (b.x < p.x + p.w && b.x + T > p.x && b.y < p.y + p.h && b.y + T > p.y) return die();
    }
  }
  // keys, doors, traps
  let next = false, dead = false;
  hit(p.x, p.y, p.w, p.h, (c, tx, ty) => {
    if (c === 'K') { map[ty][tx] = '.'; has = true; snd(880, .2, 'sine', .08); }
    if (c === 'D' && has) next = true;
    return false;
  });
  hit(p.x+4, p.y+4, p.w-8, p.h-8, (c, tx) => { if (c === '^' || c === 'X' || (c === 'H' && near(tx))) dead = true; return false; });
  if (dead || p.y > cv.height) return die();
  if (next) { lv++; snd(660, .3, 'sine', .08); if (lv >= LEVELS.length) { won = true; lv = 0; try { localStorage.removeItem('tc'); } catch (e) {} } else { save(); load(); } }
}

function brick(X, Y) {
  g.fillStyle = '#6b6490'; g.fillRect(X, Y, T, T);
  g.fillStyle = '#4e4873'; g.fillRect(X, Y+15, T, 2); g.fillRect(X+15, Y, 2, 15); g.fillRect(X+7, Y+17, 2, 15); g.fillRect(X+23, Y+17, 2, 15);
  g.fillStyle = '#8680b4'; g.fillRect(X, Y, T, 2);
}
function draw() {
  g.fillStyle = '#1b1830'; g.fillRect(0, 0, 640, 384);
  for (let x = 3; x < 20; x += 6) { // torches
    const fl = 4 + Math.sin(tick / 4 + x) * 2;
    g.fillStyle = '#543'; g.fillRect(x*T+13, 100, 6, 20);
    g.fillStyle = '#f93'; g.fillRect(x*T+16 - fl/2, 100 - fl*2, fl, fl*2);
    g.fillStyle = '#fd5'; g.fillRect(x*T+16 - fl/4, 100 - fl, fl/2, fl);
  }
  map.forEach((row, y) => row.forEach((c, x) => {
    const X = x*T, Y = y*T;
    if (c === '#' || c === 'F') brick(X, Y);
    else if (c === '^' || (c === 'H' && near(x))) {
      g.fillStyle = '#cdd'; for (let i = 0; i < 2; i++) { g.beginPath(); g.moveTo(X+i*16, Y+T); g.lineTo(X+i*16+8, Y+8); g.lineTo(X+i*16+16, Y+T); g.fill(); }
    } else if (c === 'K') { g.fillStyle = '#fc3'; g.fillRect(X+8, Y+8, 10, 10); g.fillRect(X+16, Y+12, 10, 3); g.fillRect(X+22, Y+15, 3, 5); }
    else if (c === 'D' || c === 'X') { g.fillStyle = c === 'D' && has ? '#4d6' : '#a63'; g.fillRect(X+3, Y+2, 26, 30); g.beginPath(); g.arc(X+16, Y+4, 13, Math.PI, 0); g.fill(); g.fillStyle = '#fd5'; g.fillRect(X+22, Y+18, 3, 3); }
  }));
  for (const b of blocks) if (b.st < 2) { brick(b.x, b.y); g.fillStyle = '#e45'; g.fillRect(b.x+4, b.y+T-4, T-8, 4); }
  for (const s of saws) {
    g.save(); g.translate(s.x, s.y); g.rotate(tick / 3); g.fillStyle = '#bcd';
    for (let i = 0; i < 8; i++) { g.rotate(Math.PI / 4); g.fillRect(-3, -14, 6, 8); }
    g.beginPath(); g.arc(0, 0, 10, 0, 7); g.fill(); g.fillStyle = '#556'; g.fillRect(-3, -3, 6, 6); g.restore();
  }
  // knight
  g.fillStyle = '#5bf'; g.fillRect(p.x, p.y+10, p.w, p.h-10);
  g.fillStyle = '#9ab'; g.fillRect(p.x+2, p.y, p.w-4, 12);
  g.fillStyle = '#123'; g.fillRect(p.x + (face > 0 ? 11 : 3), p.y+4, 8, 3);
  g.fillStyle = '#e44'; g.fillRect(p.x + (face > 0 ? 2 : 14), p.y-4, 6, 5);
  g.fillStyle = '#fff'; g.font = '14px sans-serif'; g.textAlign = 'left';
  g.fillText('Level ' + (won ? LEVELS.length : lv+1) + '/' + LEVELS.length + '   Deaths ' + deaths + (has ? '   KEY' : ''), 8, 16);
  if (won) { g.fillStyle = 'rgba(0,0,0,.7)'; g.fillRect(0, 130, 640, 110); g.fillStyle = '#fff'; g.font = '28px sans-serif'; g.textAlign = 'center'; g.fillText('You escaped the castle!', 320, 175); g.font = '16px sans-serif'; g.fillText('Deaths: ' + deaths + '  -  press jump to restart', 320, 210); }
}
load();
(function loop() { step(); draw(); requestAnimationFrame(loop); })();
